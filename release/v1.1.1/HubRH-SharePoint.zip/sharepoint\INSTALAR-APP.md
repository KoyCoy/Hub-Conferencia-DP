# Como instalar o Hub RH pelo SharePoint

1. Abra o link do Hub RH no Microsoft Edge ou Google Chrome.

2. No canto superior direito, clique no menu do navegador.

## No Microsoft Edge

Use:

```text
... > Apps > Instalar este site como aplicativo
```

## No Google Chrome

Use:

```text
⋮ > Transmitir, salvar e compartilhar > Instalar pagina como app
```

Dependendo da versao do Chrome, tambem pode aparecer como:

```text
⋮ > Salvar e compartilhar > Criar atalho > Abrir como janela
```

5. Confirme o nome:

```text
Hub RH
```

6. Depois disso, abra pelo Menu Iniciar do Windows procurando por:

```text
Hub RH
```

## Se nao aparecer a opcao de instalar

Use uma destas opcoes:

- `... > Apps > Instalar este site como aplicativo`
- ou clique no icone de instalacao que pode aparecer na barra de endereco.
- no Chrome, procure por `Instalar pagina como app` ou `Criar atalho`.

Se ainda nao aparecer, provavelmente o SharePoint esta abrindo o arquivo HTML em modo de visualizacao/download. Nesse caso, acione a TI para publicar a pasta como site interno ou conteudo estatico.

## Onde salvar os arquivos JSON

Use a pasta combinada pela equipe no OneDrive/SharePoint, por exemplo:

```text
RH / Hub RH / Fechamentos JSON
```

Os arquivos continuam sendo processados localmente no navegador.
